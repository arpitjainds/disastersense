from __future__ import division
import math
import csv
import random

class updateFile:
    def __init__(self):
        self.fname='/root/inpServer/data.csv'

    def update(self):
        with open(self.fname, encoding='utf-8') as File:
            reader = csv.reader(File, delimiter=',', quotechar=',', quoting=csv.QUOTE_MINIMAL)
            count=0
            isfirst = True
            finalList = []
            finalList.append(["LATITUDE", "LONGITUDE"])

            readList = []
            
            for row in reader:
                if(count==0):
                    count=1
                    continue
                longitude = float(row[2])
                latitude = float(row[3])
                radius = 6
                radius_latitude = 1.13

                lat_min = longitude - radius_latitude / abs(math.cos(math.radians(latitude)) * 69)
                lat_max = longitude + radius_latitude / abs(math.cos(math.radians(latitude)) * 69)

                lng_min = latitude - (radius / 69)
                lng_max = latitude + (radius / 69)

                final_lat = random.uniform(lat_min, lat_max)
                final_lng = random.uniform(lng_min, lng_max)

                finalList.append([final_lat, final_lng])

            with open(self.fname, encoding='utf-8') as inf:
                reader = csv.reader(inf)
                row = 0
                col = 0
                for line in reader:
                    if(isfirst):
                        readList.append(["DEVICE_ID", "MOBILE_NUMBER", "LATITUDE", "LONGITUDE", "CARRIER_NAME", "TIME_STAMP"])
                        isfirst = False
                    else:
                        readList.append([line[0], line[1], finalList[row][col], finalList[row][col+1], line[4], line[5]])
                    row = row + 1
                    col = 0

            #print(readList)

            myFile = open(self.fname, 'w', newline='', encoding='utf-8')
            with myFile:
                writer = csv.writer(myFile)
                writer.writerows(readList)
                 
                    #print("Writing complete")
#obj=updateFile()
#obj.update()
