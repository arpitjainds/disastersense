import os
import requests
import socket
from threading import Thread
import time
from updatingCoordinates import updateFile

class Socket:
    def __init__(self):
        self.s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.host = "0.0.0.0"
        self.port = 9999
        self.s.bind((self.host, self.port))
        self.s.listen(5)
        self.update_flag=0
        self.dictActive={}
        self.reset=0
        os.system("cp /root/inpServer/FinalCombinedData.csv /root/inpServer/data.csv")

    def filesend(self, id_url):
        while(self.dictActive[id_url][0]=="1"):
            try:
                self.reset+=1
                print("sending to '",id_url,"'")
                files = {'dataFile': open('/root/inpServer/data.csv', 'rb')}
                r = requests.post(id_url, files=files)
                print("sending to '",id_url,"' status: ",r.text)
                if(self.reset>10):
                    os.system("cp /root/inpServer/FinalCombinedData.csv /root/inpServer/data.csv")
                    self.reset=0
                time.sleep(30)
            except Exception as e:
                print(e)
                time.sleep(10)
                pass
        self.dictActive.pop(id_url)

    def updatefile(self):
        update_obj=updateFile()
        while(len(self.dictActive)>0):
            try:
                print("updating file")
                update_obj.update()
                print(self.dictActive)
                time.sleep(30)
            except Exception as e:
                print(e)
                time.sleep(10)
                pass
        self.update_flag=0


    def listen(self):
        while True:
            print("Listening.........")
            clientsocket,addr = self.s.accept()
            print("Got a connection from %s" % str(addr))
            msg = 'Thank you for connecting'+ "\r\n"
            clientsocket.send(msg.encode('ascii'))
            type_req=clientsocket.recv(1024)
            type_req=type_req.decode('ascii').strip()
            msg = 'got your request type'+ "\r\n"
            clientsocket.send(msg.encode('ascii'))
            id_url=clientsocket.recv(1024)
            id_url=id_url.decode('ascii').strip()
            msg = 'got your id_url'+ "\r\n"
            clientsocket.send(msg.encode('ascii'))
            if(type_req=="0"):
                self.dictActive[id_url][0]="0"
            else:
                self.dictActive[id_url]=["1"]
                self.dictActive[id_url].append(Thread(target=self.filesend, args=(id_url,)))
                self.dictActive[id_url][1].start()
                if(self.update_flag==0):
                    self.update_flag=1
                    th=Thread(target=self.updatefile)
                    th.start()
            clientsocket.close()

obj=Socket()
obj.listen()
