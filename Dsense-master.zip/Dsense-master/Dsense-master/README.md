# Dsense
<ul><li> Check the live version <a href="http://184.172.214.42:30700/">here.</a></li></ul>
<ul><li>Username:dsense & Password:welcome2dsense</li></ul>

## To build docker images:
<ul><li>Clone the repository</li></ul>
<pre>
# To build docker image of app
docker build -t dsenseapp -f Dockerfile.app

\# To build docker image of data generation server to feed demo data
docker build -t inpserver -f Dockerfile.inpServer
</pre>
## To run docker images:
<pre>
docker run --name dsenseApp -tid --env app_host={host_of_your_server} -p 8000:8000 dsenseapp
docker run --name inpServer -tid -p 9999:9999 inpserver
</pre>

<br>
<img src="ReadmePics/Slide1.JPG"/>
<img src="ReadmePics/Slide2.JPG"/>
<img src="ReadmePics/Slide3.JPG"/>
<img src="ReadmePics/Slide4.JPG"/>
<img src="ReadmePics/Slide5.JPG"/>
<img src="ReadmePics/Slide6.JPG"/>
<img src="ReadmePics/Slide7.JPG"/>
<img src="ReadmePics/Slide8.JPG"/>
<img src="ReadmePics/Slide9.JPG"/>
<img src="ReadmePics/Slide10.JPG"/>
<img src="ReadmePics/Slide11.JPG"/>
<img src="ReadmePics/Slide12.JPG"/>
<img src="ReadmePics/Slide13.JPG"/>
<img src="ReadmePics/Slide14.JPG"/>
