import pandas as pd, numpy as np, matplotlib.pyplot as plt
from sklearn.cluster import DBSCAN
from geopy.distance import great_circle
from shapely.geometry import MultiPoint

class Cluster:
    def __init__(self, filename):
        df = pd.read_csv(filename)
        print(df.shape)
        self.coords = df.as_matrix(columns=['LATITUDE', 'LONGITUDE'])
        ##print(coords)
        kms_per_radian = 6371.0088
        epsilon = 0.26 / kms_per_radian
        self.db = DBSCAN(eps=epsilon, min_samples=1, algorithm='ball_tree', metric='haversine').fit(np.radians(self.coords))
        self.cluster_labels = self.db.labels_
        self.num_clusters = len(set(self.cluster_labels))
        self.clusters = pd.Series([self.coords[self.cluster_labels == n] for n in range(self.num_clusters)])
        print('Number of clusters: {}'.format(self.num_clusters))

    def plot(self):
        n_clusters_ = len(set(self.cluster_labels)) - (1 if -1 in self.cluster_labels else 0)
        core_samples_mask = np.zeros_like(self.db.labels_, dtype=bool)
        core_samples_mask[self.db.core_sample_indices_] = True
        unique_labels = set(self.cluster_labels)
        colors = [plt.cm.Spectral(each)
                  for each in np.linspace(0, 1, len(unique_labels))]
        for k, col in zip(unique_labels, colors):
            if k == -1:
                # Black used for noise.
                col = [0, 0, 0, 1]

            class_member_mask = (self.cluster_labels == k)

            xy = self.coords[class_member_mask & core_samples_mask]
            plt.plot(xy[:, 0], xy[:, 1], 'o', markerfacecolor=tuple(col),
                     markeredgecolor='k', markersize=14)

            xy = self.coords[class_member_mask & ~core_samples_mask]
            plt.plot(xy[:, 0], xy[:, 1], 'o', markerfacecolor=tuple(col),
                     markeredgecolor='k', markersize=6)

        plt.title('Estimated number of clusters: %d' % n_clusters_)
        plt.show()

    def get_centermost_point(self, cluster):
        centroid = (MultiPoint(cluster).centroid.x, MultiPoint(cluster).centroid.y)
        centermost_point = min(cluster, key=lambda point: great_circle(point, centroid).m)
        return tuple(centermost_point)
    def generate_centre(self):
        self.centermost_points = self.clusters.map(self.get_centermost_point)
        print(self.centermost_points)
    def top(self):
        self.generate_centre()
        sorted_loc=[]
        for i in range (self.num_clusters):
            sorted_loc.append([len(self.clusters[i]),i])
        sorted_loc.sort(reverse=True)
        top=min(self.num_clusters,5)
        self.top_loc=[]
        for i in range (top):
            self.top_loc.append([sorted_loc[i][0],self.centermost_points[sorted_loc[i][1]],self.clusters[sorted_loc[i][1]]])
        print(self.top_loc)
        return self.top_loc
# obj=Cluster('BasicData.csv')
# obj.plot()
# obj.top()
