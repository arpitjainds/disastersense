import urllib3, requests, json
class Prediction:
    def __init__(self, inp):
        self.inp=inp
        print(self.inp)
        # retrieve your wml_service_credentials_username, wml_service_credentials_password, and wml_service_credentials_url from the
        # Service credentials associated with your IBM Cloud Watson Machine Learning Service instance

        self.wml_credentials={
        "url": "https://us-south.ml.cloud.ibm.com",
        "username": "0c32ac3a-b834-484b-9a68-db264d825daa",
        "password": "e7c8f23e-5ece-4674-9451-a6213c68fc04"
        }

        self.headers = urllib3.util.make_headers(basic_auth='{username}:{password}'.format(username=self.wml_credentials['username'], password=self.wml_credentials['password']))
        self.url = '{}/v3/identity/token'.format(self.wml_credentials['url'])
        self.response = requests.get(self.url, headers=self.headers)
        self.mltoken = json.loads(self.response.text).get('token')

        self.header = {'Content-Type': 'application/json', 'Authorization': 'Bearer ' + self.mltoken}
        self.pred = []
        
    def get_affected(self):
        # NOTE: manually define and pass the array(s) of values to be scored in the next line
        payload_scoring = {"fields": ["time", "depth", "magnitude", "population"], "values": self.inp}

        response_scoring = requests.post('https://us-south.ml.cloud.ibm.com/v3/wml_instances/992091b0-03ec-4fb6-9389-be2ceca8455c/deployments/152e635a-e9d2-4aaf-9b6a-c913eb1ab7f3/online', json=payload_scoring, headers=self.header)
        
        res = json.loads(response_scoring.text)['values']
        for i in res:
            self.pred.append(max(2,i[5]))
        print(self.pred)
        return self.pred

# obj=Prediction([[120000, 50, 5.5, 900], [10000, 20, 6, 1000]])
# print(obj.get_affected())
