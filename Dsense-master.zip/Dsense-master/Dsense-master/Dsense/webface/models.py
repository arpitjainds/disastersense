from django.db import models
from django.dispatch import receiver
from django.db.models.signals import post_save
from django.contrib.auth.models import User
import os
from Dsense.settings import USER_EVENT_DIRS
import pandas as pd


def eventDirName(instance):
    return "E" + str(instance.id) + "-" + instance.location


def eventDir(instance, filename):
    return os.path.join(USER_EVENT_DIRS, "{0}/{1}/{2}".format(instance.user.username, eventDirName(instance), filename))


class Event(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name="events")
    name = models.CharField(max_length=128)
    eventType = models.CharField(max_length=64)
    location = models.CharField(max_length=128)
    reportTime = models.DateTimeField(auto_now_add=True)
    eventDate = models.DateField()
    eventTime = models.TimeField()
    dataFile = models.FileField(upload_to=eventDir)
    triggerStartTime = models.DateTimeField(null=True, blank=True)
    triggerEndTime = models.DateTimeField(null=True, blank=True)


    def get_event_data_as_dict(self, dataFrame):
        if self.dataFile:
            data = dataFrame.to_dict()
            return data

    def get_longitudes(self, dataFrame):
        if self.dataFile:
            data = list(dataFrame.LONGITUDE)
            return data

    def get_latitudes(self, dataFrame):
        if self.dataFile:
            data = list(dataFrame.LATITUDE)
            return data


@receiver(post_save, sender=User)
def createUserEventDir(sender, instance, created, **kwargs):
    if created:
        path = os.path.join(USER_EVENT_DIRS, instance.username)
        if not os.path.exists(USER_EVENT_DIRS):
            os.mkdir(USER_EVENT_DIRS)
        if not os.path.exists(path):
            os.mkdir(path)



@receiver(post_save, sender=Event)
def createEventDir(sender, instance, created, **kwargs):
    if created:
        user_events_dir = os.path.join(USER_EVENT_DIRS, instance.user.username)
        event_dir_name = eventDirName(instance)
        event_dir = os.path.join(user_events_dir,  event_dir_name)
        if not os.path.exists(USER_EVENT_DIRS):
            os.mkdir(USER_EVENT_DIRS)
        if not os.path.exists(user_events_dir):
            os.mkdir(user_events_dir)
        if not os.path.exists(event_dir):
            os.mkdir(event_dir)
