from django import forms
from django.contrib.auth.models import User
from .models import Event
from django.contrib.admin import widgets


class EventForm(forms.ModelForm):
    eventDate = forms.DateField(widget = forms.SelectDateWidget())
    eventTime = forms.TimeInput(attrs={'class':'form-control'})
    class Meta():
        model = Event
        fields = [ 'name', 'eventType', 'location', 'eventDate', 'eventTime']


class EventDataForm(forms.Form):
    class Meta():
        model = Event
        fields = [ 'dataFile' ]