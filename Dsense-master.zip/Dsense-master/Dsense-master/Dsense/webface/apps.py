from django.apps import AppConfig


class WebfaceConfig(AppConfig):
    name = 'webface'
