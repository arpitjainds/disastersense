from .models import Event
import pandas as pd


