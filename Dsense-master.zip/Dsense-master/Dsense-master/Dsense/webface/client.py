import os
import socket
import time


class Socket:
    def __init__(self):
        self.s = socket.socket(socket.AF_INET, socket.SOCK_STREAM) 
        self.host = os.environ["app_host"]                           
        self.port = 9999
        self.id = id

#    def establish_connection(self):
#        self.s.connect((self.host, self.port))

    def trigger(self, id_url):
        self.s.connect((self.host, self.port))
        msg = self.s.recv(1024)
        print(msg.decode('ascii'))
        type_req="1"
        self.s.send(type_req.encode('ascii'))
        msg = self.s.recv(1024)
        print(msg.decode('ascii'))
        self.s.send(id_url.encode('ascii'))
        msg = self.s.recv(1024)
        print(msg.decode('ascii'))
        self.s.close()

    def trigclose(self, id_url):
        self.s.connect((self.host, self.port))
        msg = self.s.recv(1024)
        print(msg.decode('ascii'))
        type_req="0"
        self.s.send(type_req.encode('ascii'))
        msg = self.s.recv(1024)
        print(msg.decode('ascii'))
        self.s.send(id_url.encode('ascii'))
        msg = self.s.recv(1024)
        print(msg.decode('ascii'))
        self.s.close()

#obj=Socket()
#obj.trigger("http://localhost:8000/data/upload/1/")
#time.sleep(100)
#obj1=Socket()
#obj1.trigclose("http://localhost:8000/data/upload/1/")
