from django.shortcuts import render, get_object_or_404
from django.contrib.auth.models import User
from django.contrib.auth import login as auth_login, logout as auth_logout
from django.contrib.auth.forms import AuthenticationForm
from django.http import HttpResponse, HttpResponseRedirect
from .forms import EventForm, EventDataForm
from .models import Event
import datetime
from django.contrib.auth.decorators import login_required
from Dsense.settings import LOGIN_URL
import pandas
from ML.affected_prediction import Prediction
import json
from ML.clustering import Cluster
from geopy.geocoders import Nominatim
from django.views.decorators.csrf import csrf_exempt
from .client import Socket
import os

CARRIERS = ["Airtel", "Aircel", "BSNL", "Idea", "Jio", "MTNL", "Tata DOCOMO", "Telenor", "Vodafone"]


@login_required(login_url=LOGIN_URL)
def index(request):
    events = request.user.events.all()
    print(events)
    return render(request, "entrypoint.html", {"events": events})


@login_required(login_url=LOGIN_URL)
def registerEvent(request):
    form = EventForm()
    return render(request, "registerevent.html", { "form": form })


def login(request):
    if request.user.is_authenticated:
            return HttpResponseRedirect("/")
    if request.method == "POST":
        form = AuthenticationForm(request, data=request.POST)
        print(form.is_valid())
        if form.is_valid():
            auth_login(request, form.get_user())
            return HttpResponseRedirect("/")
        else:
            return render(request, "index.html", { "form": form })
    form = AuthenticationForm()
    return render(request, "index.html", { "form": form })


@login_required(login_url=LOGIN_URL)
def logout(request):
    auth_logout(request)
    return HttpResponseRedirect("/login")


@login_required(login_url=LOGIN_URL)
def createEvent(request):
    if request.method == "POST":
        form = EventForm(request.POST or None)
        if form.is_valid():
            event = form.save(commit=False)
            event.user = request.user
            event.save()
            return HttpResponseRedirect("/")
        else:
            return render(request, "registerevent.html", { "form": form })


@login_required(login_url=LOGIN_URL)
def triggerSenseStart(request, id):
    event = get_object_or_404(Event, id=id)
    if event.user == request.user:
        trg = Socket()
        trg.trigger("http://"+os.environ["app_host"]+":8000/data/upload/"+str(event.id)+"/")
        event.triggerStartTime = datetime.datetime.now()
        event.save()
        return HttpResponseRedirect("/event/"+str(event.id)+"/")


@login_required(login_url=LOGIN_URL)
def triggerSenseEnd(request, id):
    event = get_object_or_404(Event, id=id)
    if event.user == request.user:
        trg = Socket()
        trg.trigclose("http://"+os.environ["app_host"]+"8000/data/upload/"+str(event.id)+"/")
        event.triggerEndTime = datetime.datetime.now()
        event.save()
        return HttpResponseRedirect("/event/"+str(event.id)+"/")


@login_required(login_url=LOGIN_URL)
def getPoints(request, id):
    event = get_object_or_404(Event, id=id)
    if request.method == "GET":
        if event.dataFile:
            dataFrame = pandas.read_csv(event.dataFile)
            data = event.get_event_data_as_dict(dataFrame)
            longitudes = event.get_longitudes(dataFrame)
            latitudes = event.get_latitudes(dataFrame)
            latlang = list(zip(latitudes, longitudes))
            context = { "error":False, "latlang": latlang, "message": "Success" }
        else:
            context = { "error":True, "latlang":None, "message":"File unreachable/does not exist!" }
    else:
        context = { "error": True, "latlang": None, "message":"Request Method Error!" }
    return HttpResponse(json.dumps(context))


@csrf_exempt
def uploadEventDataFile(request, id):
    event = get_object_or_404(Event, id=id)
    if request.method == "POST":
        dataFile = request.FILES.get('dataFile')
        event.dataFile = dataFile
        event.save()
        return HttpResponse("Success")
    return HttpResponse("Failed")


@login_required(login_url=LOGIN_URL)
def eventView(request, id):
    event = get_object_or_404(Event, id=id)
    if not event.triggerStartTime == None:
        triggered = True
        triggerEnd = False
        if not event.triggerEndTime == None:
            triggerEnd = True
        if event.dataFile:
            dataFrame = pandas.read_csv(event.dataFile)
            data = event.get_event_data_as_dict(dataFrame)
            longitudes = event.get_longitudes(dataFrame)
            latitudes = event.get_latitudes(dataFrame)
            avglat = sum(latitudes)/len(latitudes)
            avglong = sum(longitudes)/len(longitudes)
            context = {
                    "event": event,
                    "latlong": zip(latitudes, longitudes),
                    "avglat": avglat,
                    "avglong": avglong,
                    "triggered": triggered,
                    "triggerEnd": triggerEnd,
            }
        else:
            context = {
                    "event": event,
                    "triggerEnd": triggerEnd,
                    "triggered": triggered,
                    "noData": True,
            }
    else:
        triggered = False
        triggerEnd = False
        context = {
                "event": event,
                "triggerEnd": triggerEnd,
                "triggered": triggered,
                "avglat": 12.9716,
                "avglong": 77.5946,
        }
    return render(request, "monitor.html", context)



@login_required(login_url=LOGIN_URL)
def getStat(request, id):
        event = get_object_or_404(Event, id=id)
        dataFrame = pandas.read_csv(event.dataFile.path)
        richter = float(request.POST.get('richtervalue'))
        depth = float(request.POST.get('depth'))
        time = event.eventTime.hour*10000 + event.eventTime.minute*100
        population = len(pandas.read_csv(event.dataFile))
        obj = Prediction([[time, depth, richter, population]])
        aff_count = int(obj.get_affected()[0])
        aff_perp = round((aff_count/population)*100, 1)
        top_obj = Cluster(event.dataFile.path)
        primeLoc = top_obj.top()
        #print(primeLoc)
        prime = dict()
        geol = Nominatim(timeout=3)
        primeList = list()
        sumPerc = 0
        for loc in primeLoc:
            prime = {}
            prime["perc"] = round((loc[0]*100)/population, 2)
            sumPerc = sumPerc + prime["perc"]
            try:
                pLocName = geol.reverse(str(loc[1][0])+","+str(loc[1][1])).raw["address"]
            except:
                pLocName = geol.reverse(str(loc[1][0])+","+str(loc[1][1])).raw["address"]
            #pLocName = geol.reverse("40.7410861, -73.9896297241625")
            #print(pLocName)
            if "commercial" in pLocName.keys():
                pLocName = pLocName["commercial"]
            elif "suburb" in pLocName.keys():
                pLocName = pLocName["suburb"]
            else:
                pLocName = list(pLocName)[1][1]
            prime["name"] = pLocName
            ##print("plocnam",pLocName)
            ##print("prime",prime)
            primeList.append(prime)
        prime = {}
        prime["perc"] = round(100 - sumPerc, 2)
        prime["name"] = "Others"
        primeList.append(prime)
        for l in primeList:
            print(l)
        carrier_count = {}
        for carrier in CARRIERS:
            carrier_count[carrier] = 0;
        for carrier in dataFrame.CARRIER_NAME:
            carrier_count[carrier] += 1
        context = {
            "aff_count": aff_count,
            "population": population,
            "carrier_count": carrier_count,
            "aff_perp": aff_perp,
            "carrier_count": carrier_count,
            "primeList": primeList,
    }
        html = render(request, "stats.html", context)
        return HttpResponse(html)
