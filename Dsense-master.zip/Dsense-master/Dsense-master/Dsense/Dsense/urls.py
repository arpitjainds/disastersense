from django.contrib import admin
from django.urls import path
from django.contrib.auth import views as auth_views
from webface.views import (login, logout, index, registerEvent, createEvent, eventView, 
    getStat, triggerSenseStart, triggerSenseEnd, uploadEventDataFile, getPoints)


urlpatterns = [
    path('login/', login, name="login"),
    path('logout/', logout, name="logout"),
    path('', index, name="index"),
    path('register/', registerEvent, name="registerEvent"),
    path('event/<int:id>/', eventView, name="eventView"),
    path('event/start_trigger/<int:id>/', triggerSenseStart, name="triggerSenseStart"),
    path('event/end_trigger/<int:id>/', triggerSenseEnd, name="triggerSenseEnd"),
    path('getstat/<int:id>/', getStat, name="getStat"),
    path('event/add/', createEvent, name="createEvent"),
    path('data/upload/<int:id>/', uploadEventDataFile, name="uploadEventDataFile"),
    path('admin/', admin.site.urls),
    path('data/getpoints/<int:id>/', getPoints, name='getPoints'),
]
